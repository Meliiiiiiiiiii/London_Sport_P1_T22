// src/genderFilter.js

// Looks for explicit "women only" / "men only" style wording in an
// activity's name. Real listings encode this as free text (there's no
// structured gender field in the dataset), so this uses word-boundary
// matching to catch common variants while avoiding false positives
// like "Chairmen's Club".
const WOMEN_PATTERN = /\b(women'?s?|ladies?|female)\b/i;
const MEN_PATTERN = /\b(men'?s?|male)\b/i;

export function detectGenderFocus(name) {
  if (!name) return "any";
  const isWomen = WOMEN_PATTERN.test(name);
  const isMen = MEN_PATTERN.test(name);
  if (isWomen && !isMen) return "women";
  if (isMen && !isWomen) return "men";
  return "any"; // covers both-matched (ambiguous) and neither-matched
}