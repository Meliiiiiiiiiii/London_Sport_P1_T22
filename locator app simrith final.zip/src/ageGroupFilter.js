// Detects kids/family-oriented sessions from naming patterns, since
// there's no structured age-group field in the dataset — similar
// situation to gender. Matches "Junior", "Kids", "Youth", "Parent & Child"
// style wording commonly used for under-18 sessions.
const KIDS_PATTERN = /\b(junior|kids?|youth|toddler|children'?s?|parent\s*&\s*(child|junior))\b/i;

export function isKidsFocused(name) {
  if (!name) return false;
  return KIDS_PATTERN.test(name);
}