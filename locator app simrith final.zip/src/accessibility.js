import accessibilityGrid from "../public/accessibility_grid.json";

export function getAccessibilityScore(lat, lng) {
  let closest = null;
  let closestDist = Infinity;

  for (const point of accessibilityGrid) {
    const dLat = point.lat - lat;
    const dLng = point.lng - lng;
    const dist = dLat * dLat + dLng * dLng;
    if (dist < closestDist) {
      closestDist = dist;
      closest = point;
    }
  }

  return closest ? closest.normalized : null;
}

export const HIGH_ACCESSIBILITY_THRESHOLD = 0.1;