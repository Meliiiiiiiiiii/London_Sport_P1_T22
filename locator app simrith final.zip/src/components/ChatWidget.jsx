import { useState, useRef, useEffect } from "react";
import { Sparkles, Send } from "lucide-react";
import { sendChatMessage } from "../api";
import { FONT_BODY, GRADIENT, useTheme } from "../theme";

export default function ChatWidget({ userLoc }) {
  const { C } = useTheme();
  const [messages, setMessages] = useState([
    { role: "assistant", content: "Hi! Ask me to find something active, or ask a question about MoveLondon." },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const send = async () => {
    const text = input.trim();
    if (!text || loading) return;

    const nextMessages = [...messages, { role: "user", content: text }];
    setMessages(nextMessages);
    setInput("");
    setLoading(true);

    try {
      const history = messages
        .filter((_, i) => i !== 0)
        .map((m) => ({ role: m.role, content: m.content }));

      const reply = await sendChatMessage(text, history, userLoc);
      setMessages([...nextMessages, { role: "assistant", content: reply }]);
    } catch (err) {
      setMessages([
        ...nextMessages,
        { role: "assistant", content: "Sorry, something went wrong. Please try again." },
      ]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      style={{
        background: C.surface,
        borderRadius: 18,
        padding: 22,
        marginTop: 18,
        border: `1px solid ${C.border}`,
      }}
    >
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 14 }}>
        <Sparkles size={15} color={C.green} />
        <span
          style={{
            fontSize: 12.5,
            fontWeight: 700,
            color: C.textPrimary,
            textTransform: "uppercase",
            letterSpacing: "0.06em",
          }}
        >
          Ask MoveLondon
        </span>
      </div>

      <div
        style={{
          maxHeight: 300,
          overflowY: "auto",
          display: "flex",
          flexDirection: "column",
          gap: 8,
          marginBottom: 14,
          paddingRight: 4,
        }}
      >
        {messages.map((m, i) => (
          <div key={i} style={{ display: "flex", justifyContent: m.role === "user" ? "flex-end" : "flex-start" }}>
            <span
              style={{
                fontFamily: FONT_BODY,
                fontSize: 13.5,
                lineHeight: 1.4,
                padding: "9px 13px",
                borderRadius: 14,
                maxWidth: "82%",
                whiteSpace: "pre-wrap",
                ...(m.role === "user"
                  ? { background: GRADIENT, color: C.white, borderBottomRightRadius: 4 }
                  : { background: C.surfaceAlt, color: C.textPrimary, borderBottomLeftRadius: 4, border: `1px solid ${C.border}` }),
              }}
            >
              {m.content}
            </span>
          </div>
        ))}
        {loading && (
          <div style={{ display: "flex", justifyContent: "flex-start" }}>
            <span
              style={{
                fontFamily: FONT_BODY,
                fontSize: 13.5,
                padding: "9px 13px",
                borderRadius: 14,
                background: C.surfaceAlt,
                color: C.textMuted,
                border: `1px solid ${C.border}`,
              }}
            >
              Thinking…
            </span>
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      <div style={{ display: "flex", gap: 8 }}>
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && send()}
          placeholder="e.g. free yoga in Camden this evening"
          disabled={loading}
          style={{
            flex: 1,
            fontFamily: FONT_BODY,
            fontSize: 14,
            padding: "11px 13px",
            borderRadius: 10,
            border: `1px solid ${C.border}`,
            background: C.surfaceAlt,
            color: C.textPrimary,
          }}
        />
        <button
          onClick={send}
          disabled={loading || !input.trim()}
          style={{
            display: "flex",
            alignItems: "center",
            gap: 6,
            fontFamily: FONT_BODY,
            fontSize: 14,
            fontWeight: 700,
            padding: "0 18px",
            borderRadius: 10,
            border: "none",
            background: GRADIENT,
            color: C.white,
            cursor: loading || !input.trim() ? "default" : "pointer",
            opacity: loading || !input.trim() ? 0.5 : 1,
          }}
        >
          <Send size={14} /> Send
        </button>
      </div>
    </div>
  );
}