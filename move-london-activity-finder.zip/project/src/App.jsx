import { useState, useCallback } from "react";
import TopNav from "./components/TopNav";
import MobileNav from "./components/MobileNav";
import SignInPage from "./pages/SignInPage";
import SignUpPage from "./pages/SignUpPage";
import ForgotPasswordPage from "./pages/ForgotPasswordPage";
import MainPage from "./pages/MainPage";
import ResultsPage from "./pages/ResultsPage";
import DetailPage from "./pages/DetailPage";
import FavoritesPage from "./pages/FavoritesPage";
import HistoryPage from "./pages/HistoryPage";
import { DATA } from "./data";
import { C } from "./theme";

export default function App() {
  const [page, setPage] = useState("signin");
  const [user, setUser] = useState(null);
  const [userLoc, setUserLoc] = useState(null);
  const [filters, setFilters] = useState({ category: "All", price: "All", distance: 3, timeSlot: "Any" });
  const [favorites, setFavorites] = useState([]);
  const [history, setHistory] = useState([]);
  const [selectedId, setSelectedId] = useState(null);
  const [hoveredId, setHoveredId] = useState(null);

  const goTo = useCallback((p) => { setPage(p); window.scrollTo?.(0, 0); }, []);

  const handleSignIn = (email, name) => {
    setUser({ email, name: name || email.split("@")[0] });
    goTo("main");
  };

  const handleSignOut = () => {
    setUser(null);
    goTo("signin");
  };

  const toggleFavorite = (id) => {
    if (!user) { goTo("signin"); return; }
    setFavorites((f) => (f.includes(id) ? f.filter((x) => x !== id) : [...f, id]));
  };

  const openDetail = (id) => {
    setSelectedId(id);
    if (user) {
      setHistory((h) => [{ id, viewedAt: Date.now() }, ...h.filter((e) => e.id !== id)].slice(0, 50));
    }
    goTo("detail");
  };

  const clearHistory = () => setHistory([]);

  const selectedActivity = DATA.find((d) => d.id === selectedId);

  return (
    <div style={{ background: C.bg, minHeight: "100vh" }}>
      {(page === "signin" || page === "signup" || page === "forgot") ? (
        page === "signin" ? <SignInPage goTo={goTo} onSignIn={handleSignIn} /> :
        page === "signup" ? <SignUpPage goTo={goTo} onSignIn={handleSignIn} /> :
        <ForgotPasswordPage goTo={goTo} />
      ) : (
        <>
          <TopNav goTo={goTo} user={user} onSignOut={handleSignOut} current={page} />
          {page === "main" && (
            <MainPage
              goTo={goTo} userLoc={userLoc} setUserLoc={setUserLoc}
              filters={filters} setFilters={setFilters}
              onSearch={() => goTo("results")}
            />
          )}
          {page === "results" && userLoc && (
            <ResultsPage
              goTo={goTo} userLoc={userLoc} filters={filters}
              favorites={favorites} toggleFavorite={toggleFavorite}
              onOpenDetail={openDetail} hoveredId={hoveredId} setHoveredId={setHoveredId}
            />
          )}
          {page === "detail" && (
            <DetailPage goTo={goTo} activity={selectedActivity} favorites={favorites} toggleFavorite={toggleFavorite} userLoc={userLoc} />
          )}
          {page === "favorites" && (
            <FavoritesPage goTo={goTo} user={user} favorites={favorites} toggleFavorite={toggleFavorite} onOpenDetail={openDetail} />
          )}
          {page === "history" && (
            <HistoryPage goTo={goTo} user={user} history={history} favorites={favorites} toggleFavorite={toggleFavorite} onOpenDetail={openDetail} clearHistory={clearHistory} />
          )}
          <MobileNav goTo={goTo} current={page} user={user} />
        </>
      )}
    </div>
  );
}
