import { useEffect } from "react";
import { MapContainer, TileLayer, CircleMarker, Tooltip, useMap } from "react-leaflet";
import "leaflet/dist/leaflet.css";
import { C, CAT_DOT_COLOR } from "../theme";

function FitBounds({ points, userPoint }) {
  const map = useMap();
  useEffect(() => {
    const coords = [];
    if (userPoint) coords.push([userPoint.lat, userPoint.lng]);
    points.forEach((p) => coords.push([p.lat, p.lng]));
    if (coords.length === 0) return;
    if (coords.length === 1) {
      map.setView(coords[0], 14);
    } else {
      map.fitBounds(coords, { padding: [30, 30], maxZoom: 15 });
    }
  }, [points, userPoint, map]);
  return null;
}

export default function RealMap({ points, userPoint, selectedId, onSelect, height = 260 }) {
  const safePoints = (points || []).filter(
    (p) => p && typeof p.lat === "number" && typeof p.lng === "number" && !isNaN(p.lat) && !isNaN(p.lng)
  );
  const fallbackCenter = [51.5074, -0.1278];
  const center = userPoint
    ? [userPoint.lat, userPoint.lng]
    : safePoints.length > 0
    ? [safePoints[0].lat, safePoints[0].lng]
    : fallbackCenter;

  return (
    <div style={{ width: "100%", height, borderRadius: 18, overflow: "hidden", border: `1px solid ${C.border}` }}>
      <MapContainer center={center} zoom={13} style={{ width: "100%", height: "100%", background: C.surface }} scrollWheelZoom={true}>
        {/* CartoDB Dark Matter tiles - free, no API key, matches the app's dark theme */}
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>'
          url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
        />
        <FitBounds points={safePoints} userPoint={userPoint} />

        {safePoints.map((p) => (
          <CircleMarker
            key={p.id}
            center={[p.lat, p.lng]}
            radius={p.id === selectedId ? 9 : 6}
            pathOptions={{
              color: p.id === selectedId ? "#FFFFFF" : "transparent",
              weight: p.id === selectedId ? 2 : 0,
              fillColor: CAT_DOT_COLOR[p.type] || "#7A93A8",
              fillOpacity: 0.9,
            }}
            eventHandlers={{ click: () => onSelect && onSelect(p.id) }}
          >
            <Tooltip direction="top" offset={[0, -6]} opacity={0.95}>
              {p.name}
            </Tooltip>
          </CircleMarker>
        ))}

        {userPoint && (
          <CircleMarker
            center={[userPoint.lat, userPoint.lng]}
            radius={9}
            pathOptions={{ color: "#FFFFFF", weight: 2, fillColor: C.green, fillOpacity: 1 }}
          >
            <Tooltip direction="top" offset={[0, -8]} opacity={0.95} permanent>
              You are here
            </Tooltip>
          </CircleMarker>
        )}
      </MapContainer>
    </div>
  );
}
