import * as Icons from "lucide-react";
import { ArrowLeft, Heart, MapPin, Clock, Calendar, Navigation, ExternalLink } from "lucide-react";
import SchematicMap from "../components/SchematicMap";
import Footer from "../components/Footer";
import Row from "../components/Row";
import { haversine } from "../utils";
import { C, FONT_DISPLAY, FONT_BODY, FONT_MONO, CAT_DOT_COLOR, CAT_ICON } from "../theme";

export default function DetailPage({ goTo, activity, favorites, toggleFavorite, userLoc }) {
  if (!activity) return null;
  const distance = userLoc ? haversine(userLoc.lat, userLoc.lng, activity.lat, activity.lng).toFixed(1) : null;
  const isFav = favorites.includes(activity.id);
  const IconComp = Icons[CAT_ICON[activity.type]] || Icons.Sparkles;
  const catColor = CAT_DOT_COLOR[activity.type] || "#7A93A8";

  return (
    <div className="page-with-mobile-nav" style={{ background: C.bg, minHeight: 640, fontFamily: FONT_BODY }}>
      <div style={{ maxWidth: 640, margin: "0 auto", padding: "26px 24px 10px" }}>
        <button onClick={() => goTo("results")} style={{ display: "flex", alignItems: "center", gap: 6, fontFamily: FONT_BODY, fontSize: 13.5, color: C.textSecondary, background: "none", border: "none", cursor: "pointer", marginBottom: 16, fontWeight: 600 }}>
          <ArrowLeft size={15} /> Back to results
        </button>

        <SchematicMap points={[activity]} userPoint={userLoc} selectedId={activity.id} height={220} />

        <div style={{ background: C.surface, borderRadius: 18, padding: 26, marginTop: -18, position: "relative", border: `1px solid ${C.border}` }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 12 }}>
            <div style={{ display: "flex", gap: 14, alignItems: "flex-start" }}>
              <div style={{
                width: 46, height: 46, borderRadius: 14, flexShrink: 0,
                background: `${catColor}22`, display: "flex", alignItems: "center", justifyContent: "center",
              }}>
                <IconComp size={22} color={catColor} />
              </div>
              <div>
                <span style={{ fontFamily: FONT_MONO, fontSize: 11.5, fontWeight: 700, color: C.green, textTransform: "uppercase", letterSpacing: "0.06em" }}>
                  {activity.type}
                </span>
                <h1 style={{ fontFamily: FONT_DISPLAY, fontSize: 22, fontWeight: 800, color: C.textPrimary, margin: "5px 0 0" }}>
                  {activity.name}
                </h1>
              </div>
            </div>
            <button onClick={() => toggleFavorite(activity.id)} style={{ background: C.surfaceAlt, border: `1px solid ${C.border}`, borderRadius: 12, padding: 10, cursor: "pointer", flexShrink: 0 }}>
              <Heart size={19} color={isFav ? C.green : C.textMuted} fill={isFav ? C.green : "none"} />
            </button>
          </div>

          <div style={{ display: "flex", gap: 10, marginTop: 18, marginBottom: 24, flexWrap: "wrap" }}>
            <span style={{ fontFamily: FONT_MONO, fontSize: 13, fontWeight: 700, padding: "6px 13px", borderRadius: 999, background: activity.free ? C.goldSoft : C.surfaceAlt, color: activity.free ? C.gold : C.textPrimary }}>
              {activity.free ? "FREE" : `£${activity.price.toFixed(2)}`}
            </span>
            {distance && (
              <span style={{ fontFamily: FONT_MONO, fontSize: 13, color: C.textSecondary, display: "flex", alignItems: "center", gap: 5 }}>
                <Navigation size={13} /> {distance} mi away
              </span>
            )}
          </div>

          <div style={{ display: "flex", flexDirection: "column", gap: 16, paddingTop: 20, borderTop: `1px solid ${C.border}` }}>
            <Row icon={MapPin} label="Location">
              {activity.venue}{activity.address ? `, ${activity.address}` : ""}<br />
              {activity.postcode} · {activity.borough}
            </Row>
            {activity.time && (
              <Row icon={Clock} label="Start time">{activity.time}</Row>
            )}
            {activity.days && (
              <Row icon={Calendar} label="Runs on">{activity.days}</Row>
            )}
          </div>

          {activity.url ? (
            <a
              href={activity.url} target="_blank" rel="noopener noreferrer"
              style={{
                display: "flex", alignItems: "center", justifyContent: "center", gap: 8,
                marginTop: 26, fontFamily: FONT_BODY, fontWeight: 700, fontSize: 15,
                background: "linear-gradient(135deg, #2E7BB0, #22A06B)", color: C.white, borderRadius: 999, padding: "15px 22px",
                textDecoration: "none", boxShadow: "0 8px 30px rgba(34,160,107,0.25)",
              }}
            >
              Book this activity <ExternalLink size={15} />
            </a>
          ) : (
            <div style={{ marginTop: 24, textAlign: "center", fontFamily: FONT_BODY, fontSize: 13.5, color: C.textMuted, padding: "12px 0" }}>
              No booking link available for this session — contact the venue directly.
            </div>
          )}
        </div>
      </div>
      <Footer />
    </div>
  );
}
