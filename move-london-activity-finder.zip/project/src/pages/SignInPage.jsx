import { useState } from "react";
import { Mail, Lock } from "lucide-react";
import Logo from "../components/Logo";
import Field from "../components/Field";
import { PrimaryButton, GhostButton } from "../components/Buttons";
import AuthShell from "../components/AuthShell";
import { isValidEmail } from "../utils";
import { C, FONT_DISPLAY, FONT_BODY } from "../theme";

export default function SignInPage({ goTo, onSignIn }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [touched, setTouched] = useState(false);

  const emailError = touched && email.length > 0 && !isValidEmail(email)
    ? "Enter a valid email address (e.g. you@example.com)"
    : null;

  const canSubmit = email.length > 0 && isValidEmail(email) && password.length > 0;

  const handleSubmit = () => {
    setTouched(true);
    if (!isValidEmail(email)) return;
    onSignIn(email);
  };

  return (
    <AuthShell>
      <div style={{ marginBottom: 30 }}>
        <Logo />
      </div>
      <h1 style={{ fontFamily: FONT_DISPLAY, fontSize: 26, fontWeight: 800, color: C.textPrimary, margin: "0 0 6px" }}>
        Welcome back
      </h1>
      <p style={{ fontFamily: FONT_BODY, fontSize: 14, color: C.textSecondary, margin: "0 0 26px" }}>
        Sign in to save activities and pick up where you left off.
      </p>
      <Field
        icon={Mail} label="Email" type="email" value={email}
        onChange={(e) => { setEmail(e.target.value); setTouched(true); }}
        placeholder="you@example.com"
        error={emailError}
      />
      <Field icon={Lock} label="Password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••" />
      <div style={{ textAlign: "right", marginTop: -8, marginBottom: 20 }}>
        <button
          onClick={() => goTo("forgot")}
          style={{ fontFamily: FONT_BODY, fontSize: 13, color: C.green, background: "none", border: "none", cursor: "pointer", fontWeight: 600 }}
        >
          Forgot password?
        </button>
      </div>
      <PrimaryButton full onClick={handleSubmit} disabled={touched && !canSubmit}>
        Sign in
      </PrimaryButton>
      <GhostButton full style={{ marginTop: 10, width: "100%", boxSizing: "border-box" }} onClick={() => goTo("main")}>
        Continue without an account
      </GhostButton>
      <p style={{ fontFamily: FONT_BODY, fontSize: 13.5, color: C.textSecondary, textAlign: "center", marginTop: 22 }}>
        New here?{" "}
        <button onClick={() => goTo("signup")} style={{ color: C.green, fontWeight: 700, background: "none", border: "none", cursor: "pointer", fontFamily: FONT_BODY, fontSize: 13.5 }}>
          Create an account
        </button>
      </p>
    </AuthShell>
  );
}
