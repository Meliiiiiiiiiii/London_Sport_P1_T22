import { useState } from "react";
import { Mail, Lock, User } from "lucide-react";
import Logo from "../components/Logo";
import Field from "../components/Field";
import { PrimaryButton } from "../components/Buttons";
import AuthShell from "../components/AuthShell";
import { isValidEmail } from "../utils";
import { C, FONT_DISPLAY, FONT_BODY } from "../theme";

export default function SignUpPage({ goTo, onSignIn }) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [touched, setTouched] = useState(false);

  const emailError = touched && email.length > 0 && !isValidEmail(email)
    ? "Enter a valid email address (e.g. you@example.com)"
    : null;

  const canSubmit = email.length > 0 && isValidEmail(email) && password.length > 0;

  const handleSubmit = () => {
    setTouched(true);
    if (!isValidEmail(email)) return;
    onSignIn(email, name);
  };

  return (
    <AuthShell>
      <div style={{ marginBottom: 30 }}>
        <Logo />
      </div>
      <h1 style={{ fontFamily: FONT_DISPLAY, fontSize: 26, fontWeight: 800, color: C.textPrimary, margin: "0 0 6px" }}>
        Create your account
      </h1>
      <p style={{ fontFamily: FONT_BODY, fontSize: 14, color: C.textSecondary, margin: "0 0 26px" }}>
        Free to join. Save activities and build your routine.
      </p>
      <Field icon={User} label="Name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Your name" />
      <Field
        icon={Mail} label="Email" type="email" value={email}
        onChange={(e) => { setEmail(e.target.value); setTouched(true); }}
        placeholder="you@example.com"
        error={emailError}
      />
      <Field icon={Lock} label="Password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="At least 8 characters" />
      <PrimaryButton full onClick={handleSubmit} disabled={touched && !canSubmit} style={{ marginTop: 4 }}>
        Create account
      </PrimaryButton>
      <p style={{ fontFamily: FONT_BODY, fontSize: 13.5, color: C.textSecondary, textAlign: "center", marginTop: 22 }}>
        Already have an account?{" "}
        <button onClick={() => goTo("signin")} style={{ color: C.green, fontWeight: 700, background: "none", border: "none", cursor: "pointer", fontFamily: FONT_BODY, fontSize: 13.5 }}>
          Sign in
        </button>
      </p>
    </AuthShell>
  );
}
