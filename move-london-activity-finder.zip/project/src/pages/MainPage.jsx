import { useState } from "react";
import { MapPin, Search, Filter, Navigation, AlertCircle } from "lucide-react";
import SchematicMap from "../components/SchematicMap";
import { PrimaryButton, GhostButton } from "../components/Buttons";
import Footer from "../components/Footer";
import { DATA, CATEGORIES, BOROUGH_CENTROIDS } from "../data";
import { C, FONT_DISPLAY, FONT_BODY, FONT_MONO, GRADIENT_SOFT } from "../theme";

export default function MainPage({ goTo, userLoc, setUserLoc, filters, setFilters, onSearch }) {
  const [manualOpen, setManualOpen] = useState(false);
  const [geoError, setGeoError] = useState("");
  const [geoLoading, setGeoLoading] = useState(false);

  const useMyLocation = () => {
    setGeoError("");
    setGeoLoading(true);
    if (!navigator.geolocation) {
      setGeoError("Location isn't available in this browser. Pick a starting point manually instead.");
      setGeoLoading(false);
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setUserLoc({ label: "Your current location", lat: pos.coords.latitude, lng: pos.coords.longitude });
        setGeoLoading(false);
      },
      () => {
        setGeoError("Location permission denied. Pick a starting point manually instead.");
        setGeoLoading(false);
      },
      { timeout: 8000 }
    );
  };

  return (
    <div className="page-with-mobile-nav" style={{ background: C.bg, minHeight: 640, fontFamily: FONT_BODY, position: "relative", overflow: "hidden" }}>
      {/* ambient decorative glow */}
      <div style={{ position: "absolute", width: 520, height: 520, borderRadius: "50%", background: GRADIENT_SOFT, filter: "blur(100px)", top: -220, right: -160, pointerEvents: "none" }} />

      <div style={{ maxWidth: 720, margin: "0 auto", padding: "48px 24px 20px", position: "relative" }}>
        <h1 className="hero-title" style={{ fontFamily: FONT_DISPLAY, fontWeight: 800, color: C.textPrimary, margin: "0 0 10px", letterSpacing: "-0.02em", lineHeight: 1.15 }}>
          Find something active,{" "}
          <span style={{
            background: "linear-gradient(135deg, #2E7BB0, #22A06B)",
            WebkitBackgroundClip: "text", backgroundClip: "text", color: "transparent",
          }}>near you.</span>
        </h1>
        <p style={{ fontSize: 15, color: C.textSecondary, margin: "0 0 32px", maxWidth: 480 }}>
          Real sessions across London — free and paid, sorted by distance from wherever you are.
        </p>

        {/* Location entry */}
        <div style={{ background: C.surface, borderRadius: 18, padding: 22, marginBottom: 18, border: `1px solid ${C.border}` }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: userLoc ? 14 : 0 }}>
            <div style={{ width: 34, height: 34, borderRadius: 10, background: C.greenSoft, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
              <MapPin size={16} color={C.green} />
            </div>
            <span style={{ fontFamily: FONT_BODY, fontSize: 14.5, fontWeight: 700, color: C.textPrimary }}>
              {userLoc ? userLoc.label : "Where are you starting from?"}
            </span>
          </div>
          {!userLoc && (
            <div style={{ display: "flex", gap: 10, flexWrap: "wrap", marginTop: 14 }}>
              <PrimaryButton onClick={useMyLocation} disabled={geoLoading}>
                <span style={{ display: "flex", alignItems: "center", gap: 7 }}>
                  <Navigation size={15} /> {geoLoading ? "Locating…" : "Use my location"}
                </span>
              </PrimaryButton>
              <GhostButton onClick={() => setManualOpen((v) => !v)}>Choose manually</GhostButton>
            </div>
          )}
          {geoError && (
            <p style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 13, color: C.danger, marginTop: 10 }}>
              <AlertCircle size={14} /> {geoError}
            </p>
          )}
          {manualOpen && !userLoc && (
            <div style={{ marginTop: 16, display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(150px, 1fr))", gap: 8, maxHeight: 190, overflowY: "auto" }}>
              {BOROUGH_CENTROIDS.map((b) => (
                <button
                  key={b.name}
                  onClick={() => setUserLoc({ label: b.name, lat: b.lat, lng: b.lng })}
                  style={{ fontFamily: FONT_BODY, fontSize: 13, textAlign: "left", padding: "9px 11px", borderRadius: 10, border: `1px solid ${C.border}`, background: C.surfaceAlt, cursor: "pointer", color: C.textPrimary }}
                >
                  {b.name}
                </button>
              ))}
            </div>
          )}
          {userLoc && (
            <>
              <div style={{ marginTop: 4, marginBottom: 14 }}>
                <SchematicMap points={DATA} userPoint={userLoc} height={200} />
              </div>
              <button
                onClick={() => setUserLoc(null)}
                style={{ fontFamily: FONT_BODY, fontSize: 12.5, color: C.textSecondary, background: "none", border: "none", cursor: "pointer", padding: 0, textDecoration: "underline" }}
              >
                Change location
              </button>
            </>
          )}
        </div>

        {/* Filters */}
        <div style={{ background: C.surface, borderRadius: 18, padding: 22, border: `1px solid ${C.border}` }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 18 }}>
            <Filter size={15} color={C.green} />
            <span style={{ fontSize: 12.5, fontWeight: 700, color: C.textPrimary, textTransform: "uppercase", letterSpacing: "0.06em" }}>Filters</span>
          </div>

          <div className="filter-grid" style={{ marginBottom: 4 }}>
            <div>
              <label style={{ fontSize: 12, fontWeight: 700, color: C.textSecondary, textTransform: "uppercase", letterSpacing: "0.05em", display: "block", marginBottom: 7 }}>Category</label>
              <select
                value={filters.category}
                onChange={(e) => setFilters((f) => ({ ...f, category: e.target.value }))}
                style={{ width: "100%", fontFamily: FONT_BODY, fontSize: 14, padding: "11px 11px", borderRadius: 10, border: `1px solid ${C.border}`, background: C.surfaceAlt, color: C.textPrimary }}
              >
                <option value="All">All activities</option>
                {CATEGORIES.map((c) => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>
            <div>
              <label style={{ fontSize: 12, fontWeight: 700, color: C.textSecondary, textTransform: "uppercase", letterSpacing: "0.05em", display: "block", marginBottom: 7 }}>Price</label>
              <select
                value={filters.price}
                onChange={(e) => setFilters((f) => ({ ...f, price: e.target.value }))}
                style={{ width: "100%", fontFamily: FONT_BODY, fontSize: 14, padding: "11px 11px", borderRadius: 10, border: `1px solid ${C.border}`, background: C.surfaceAlt, color: C.textPrimary }}
              >
                <option value="All">Free & paid</option>
                <option value="Free">Free only</option>
                <option value="Paid">Paid only</option>
              </select>
            </div>
          </div>

          <div style={{ marginTop: 20 }}>
            <label style={{ fontSize: 12, fontWeight: 700, color: C.textSecondary, textTransform: "uppercase", letterSpacing: "0.05em", display: "flex", justifyContent: "space-between" }}>
              <span>Distance</span>
              <span style={{ fontFamily: FONT_MONO, color: C.green }}>{filters.distance} mi</span>
            </label>
            <input
              type="range" min="0.5" max="10" step="0.5" value={filters.distance}
              onChange={(e) => setFilters((f) => ({ ...f, distance: parseFloat(e.target.value) }))}
              style={{ width: "100%", marginTop: 10 }}
            />
          </div>

          <div style={{ marginTop: 20, marginBottom: 4 }}>
            <label style={{ fontSize: 12, fontWeight: 700, color: C.textSecondary, textTransform: "uppercase", letterSpacing: "0.05em", display: "block", marginBottom: 9 }}>Time of day</label>
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
              {["Any", "Morning", "Afternoon", "Evening"].map((slot) => {
                const active = filters.timeSlot === slot;
                return (
                  <button
                    key={slot}
                    onClick={() => setFilters((f) => ({ ...f, timeSlot: slot }))}
                    style={{
                      fontFamily: FONT_BODY, fontSize: 13, fontWeight: 600, padding: "8px 15px", borderRadius: 999,
                      border: active ? "none" : `1px solid ${C.border}`,
                      background: active ? "linear-gradient(135deg, #2E7BB0, #22A06B)" : "transparent",
                      color: active ? C.white : C.textSecondary, cursor: "pointer",
                    }}
                  >
                    {slot}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        <PrimaryButton full style={{ marginTop: 22, padding: "16px 22px", fontSize: 16 }} onClick={onSearch} disabled={!userLoc}>
          <span style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}>
            <Search size={17} /> {userLoc ? "Find activities" : "Set your location to search"}
          </span>
        </PrimaryButton>
      </div>
      <Footer />
    </div>
  );
}
