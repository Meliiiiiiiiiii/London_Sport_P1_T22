import { useState } from "react";
import { Mail, ArrowLeft, Info } from "lucide-react";
import Logo from "../components/Logo";
import Field from "../components/Field";
import { PrimaryButton } from "../components/Buttons";
import AuthShell from "../components/AuthShell";
import { isValidEmail } from "../utils";
import { C, FONT_DISPLAY, FONT_BODY } from "../theme";

export default function ForgotPasswordPage({ goTo }) {
  const [email, setEmail] = useState("");
  const [touched, setTouched] = useState(false);
  const [sent, setSent] = useState(false);

  const emailError = touched && email.length > 0 && !isValidEmail(email)
    ? "Enter a valid email address (e.g. you@example.com)"
    : null;

  const canSubmit = email.length > 0 && isValidEmail(email);

  const handleSubmit = () => {
    setTouched(true);
    if (!isValidEmail(email)) return;
    setSent(true);
  };

  return (
    <AuthShell>
      <div style={{ marginBottom: 30 }}>
        <Logo />
      </div>
      {!sent ? (
        <>
          <h1 style={{ fontFamily: FONT_DISPLAY, fontSize: 24, fontWeight: 800, color: C.textPrimary, margin: "0 0 6px" }}>
            Reset your password
          </h1>
          <p style={{ fontFamily: FONT_BODY, fontSize: 14, color: C.textSecondary, margin: "0 0 26px" }}>
            Enter your email and we'll send a link to reset it.
          </p>
          <Field
            icon={Mail} label="Email" type="email" value={email}
            onChange={(e) => { setEmail(e.target.value); setTouched(true); }}
            placeholder="you@example.com"
            error={emailError}
          />
          <PrimaryButton full onClick={handleSubmit} disabled={touched && !canSubmit}>
            Send reset link
          </PrimaryButton>
        </>
      ) : (
        <div style={{ textAlign: "center", padding: "12px 0" }}>
          <div style={{ width: 54, height: 54, borderRadius: "50%", background: "linear-gradient(135deg, #2E7BB0, #22A06B)", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 18px" }}>
            <Mail size={24} color={C.white} />
          </div>
          <h2 style={{ fontFamily: FONT_DISPLAY, fontSize: 19, color: C.textPrimary, margin: "0 0 8px" }}>Request received</h2>
          <p style={{ fontFamily: FONT_BODY, fontSize: 14, color: C.textSecondary, margin: "0 0 18px" }}>
            In a live version, a reset link would now be on its way to <strong style={{ color: C.textPrimary }}>{email}</strong>.
          </p>
          <div style={{ display: "flex", alignItems: "flex-start", gap: 8, background: C.surfaceAlt, border: `1px solid ${C.border}`, borderRadius: 12, padding: "12px 14px", textAlign: "left" }}>
            <Info size={15} color={C.textSecondary} style={{ flexShrink: 0, marginTop: 1 }} />
            <span style={{ fontFamily: FONT_BODY, fontSize: 12.5, color: C.textSecondary, lineHeight: 1.5 }}>
              This is a working prototype — no real email is sent yet. Actually sending one requires a backend email service (e.g. Firebase Auth or Supabase), which isn't wired in.
            </span>
          </div>
        </div>
      )}
      <button
        onClick={() => goTo("signin")}
        style={{
          display: "flex", alignItems: "center", gap: 6, margin: "22px auto 0",
          fontFamily: FONT_BODY, fontSize: 13.5, color: C.green, fontWeight: 700,
          background: "none", border: "none", cursor: "pointer",
        }}
      >
        <ArrowLeft size={15} /> Back to sign in
      </button>
    </AuthShell>
  );
}
