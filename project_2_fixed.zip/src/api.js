const API_URL = "https://c4tkoi5bqwa4toay4323uunop40wicgj.lambda-url.eu-north-1.on.aws/";

// Converts raw DynamoDB fields into the shape the app's components expect
function mapItem(raw) {
  const price = typeof raw.price_gbp === "number" ? raw.price_gbp : 0;
  const free = typeof raw.is_free === "boolean" ? raw.is_free : price === 0;
  return {
    id: raw.session_id,
    lat: raw.latitude,
    lng: raw.longitude,
    type: raw.activity_type || "Other / Unspecified",
    free,
    price,
    time: raw.start_time || null,
    name: raw.name || raw.location_name || "Activity",
    borough: raw.borough || "",
    locationName: raw.location_name || "",
    url: raw.url || null,
  };
}

export async function fetchActivities({ category, price } = {}) {
  const params = new URLSearchParams();
  if (category && category !== "All") params.set("category", category);
  if (price && price !== "All") params.set("price", price);
  params.set("limit", "3000");

  const res = await fetch(`${API_URL}?${params.toString()}`);
  if (!res.ok) throw new Error("Failed to load activities");
  const data = await res.json();

  return (data.items || [])
    .filter((raw) => typeof raw.latitude === "number" && typeof raw.longitude === "number")
    .map(mapItem);
}