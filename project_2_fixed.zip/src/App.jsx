import { useState, useCallback, useEffect, useRef } from "react";
import TopNav from "./components/TopNav";
import MobileNav from "./components/MobileNav";
import SignInPage from "./pages/SignInPage";
import SignUpPage from "./pages/SignUpPage";
import ForgotPasswordPage from "./pages/ForgotPasswordPage";
import MainPage from "./pages/MainPage";
import ResultsPage from "./pages/ResultsPage";
import DetailPage from "./pages/DetailPage";
import FavoritesPage from "./pages/FavoritesPage";
import HistoryPage from "./pages/HistoryPage";
import { DATA } from "./data";
import { C } from "./theme";

// Namespaced localStorage helpers, keyed per signed-in user so different
// accounts on the same browser don't see each other's data.
function storageKey(email, name) {
  return `activities_${name}_${email}`;
}
function loadStored(email, name, fallback) {
  if (!email) return fallback;
  try {
    const raw = localStorage.getItem(storageKey(email, name));
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
}
function saveStored(email, name, value) {
  if (!email) return;
  try {
    localStorage.setItem(storageKey(email, name), JSON.stringify(value));
  } catch {
    // ignore quota / serialization errors
  }
}
// The activity cache (full objects for live-search results) is shared across
// accounts on this browser -- it's just a lookup table, not personal data.
function loadCache() {
  try {
    const raw = localStorage.getItem("activities_cache");
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}
function saveCache(value) {
  try {
    localStorage.setItem("activities_cache", JSON.stringify(value));
  } catch {
    // ignore
  }
}

export default function App() {
  const [page, setPage] = useState("signin");
  const [user, setUser] = useState(null);
  const [userLoc, setUserLoc] = useState(null);
  const [filters, setFilters] = useState({ category: "All", price: "All", distance: 3, timeSlot: "Any" });
  const [favorites, setFavorites] = useState([]);
  const [history, setHistory] = useState([]);
  const [selectedId, setSelectedId] = useState(null);
  const [hoveredId, setHoveredId] = useState(null);
  const [activityCache, setActivityCache] = useState(() => loadCache());

  // Don't persist favorites/history until we've actually loaded the
  // signed-in user's saved data, or the initial empty state would
  // immediately overwrite what's in localStorage.
  const hydratedRef = useRef(false);

  const goTo = useCallback((p) => { setPage(p); window.scrollTo?.(0, 0); }, []);

  const handleSignIn = (email, name) => {
    const resolvedName = name || email.split("@")[0];
    hydratedRef.current = false;
    setFavorites(loadStored(email, "favorites", []));
    setHistory(loadStored(email, "history", []));
    hydratedRef.current = true;
    setUser({ email, name: resolvedName });
    goTo("main");
  };

  const handleSignOut = () => {
    hydratedRef.current = false;
    setUser(null);
    setFavorites([]);
    setHistory([]);
    goTo("signin");
  };

  // Persist favorites/history to localStorage for the current user whenever they change.
  useEffect(() => {
    if (!user || !hydratedRef.current) return;
    saveStored(user.email, "favorites", favorites);
  }, [favorites, user]);

  useEffect(() => {
    if (!user || !hydratedRef.current) return;
    saveStored(user.email, "history", history);
  }, [history, user]);

  // Persist the activity lookup cache so favorited/viewed live-search
  // results can still be resolved after a refresh.
  useEffect(() => {
    saveCache(activityCache);
  }, [activityCache]);

  const toggleFavorite = (idOrActivity) => {
    if (!user) { goTo("signin"); return; }
    let id = idOrActivity;
    if (typeof idOrActivity === "object" && idOrActivity !== null) {
      id = idOrActivity.id;
      setActivityCache((c) => ({ ...c, [id]: idOrActivity }));
    }
    setFavorites((f) => (f.includes(id) ? f.filter((x) => x !== id) : [...f, id]));
  };

  // Accepts either a full activity object (from live search results) or
  // just an id (from Favorites/History)
  const openDetail = (activityOrId) => {
    let id, fullActivity;
    if (typeof activityOrId === "object" && activityOrId !== null) {
      fullActivity = activityOrId;
      id = activityOrId.id;
      setActivityCache((c) => ({ ...c, [id]: fullActivity }));
    } else {
      id = activityOrId;
    }
    setSelectedId(id);
    if (user) {
      setHistory((h) => [{ id, viewedAt: Date.now() }, ...h.filter((e) => e.id !== id)].slice(0, 50));
    }
    goTo("detail");
  };

  const clearHistory = () => setHistory([]);

  const selectedActivity = activityCache[selectedId] || DATA.find((d) => d.id === selectedId);

  return (
    <div style={{ background: C.bg, minHeight: "100vh" }}>
      {(page === "signin" || page === "signup" || page === "forgot") ? (
        page === "signin" ? <SignInPage goTo={goTo} onSignIn={handleSignIn} /> :
        page === "signup" ? <SignUpPage goTo={goTo} onSignIn={handleSignIn} /> :
        <ForgotPasswordPage goTo={goTo} />
      ) : (
        <>
          <TopNav goTo={goTo} user={user} onSignOut={handleSignOut} current={page} />
          {page === "main" && (
            <MainPage
              goTo={goTo} userLoc={userLoc} setUserLoc={setUserLoc}
              filters={filters} setFilters={setFilters}
              onSearch={() => goTo("results")}
            />
          )}
          {page === "results" && userLoc && (
            <ResultsPage
              goTo={goTo} userLoc={userLoc} setUserLoc={setUserLoc} filters={filters}
              favorites={favorites} toggleFavorite={toggleFavorite}
              onOpenDetail={openDetail} hoveredId={hoveredId} setHoveredId={setHoveredId}
            />
          )}
          {page === "detail" && (
            <DetailPage goTo={goTo} activity={selectedActivity} favorites={favorites} toggleFavorite={toggleFavorite} userLoc={userLoc} />
          )}
          {page === "favorites" && (
            <FavoritesPage goTo={goTo} user={user} favorites={favorites} toggleFavorite={toggleFavorite} onOpenDetail={openDetail} activityCache={activityCache} />
          )}
          {page === "history" && (
            <HistoryPage goTo={goTo} user={user} history={history} favorites={favorites} toggleFavorite={toggleFavorite} onOpenDetail={openDetail} clearHistory={clearHistory} activityCache={activityCache} />
          )}
          <MobileNav goTo={goTo} current={page} user={user} />
        </>
      )}
    </div>
  );
}