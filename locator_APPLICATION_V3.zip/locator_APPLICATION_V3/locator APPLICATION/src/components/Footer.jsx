import { FONT_MONO, useTheme } from "../theme";

export default function Footer() {
  const { C } = useTheme();
  return (
    <div style={{ textAlign: "center", padding: "24px 16px 30px", fontFamily: FONT_MONO, fontSize: 11, color: C.textMuted, letterSpacing: "0.04em" }}>
      ACTIVITY DATA REFRESHED WEEKLY · SOURCE: OPENACTIVE
    </div>
  );
}
