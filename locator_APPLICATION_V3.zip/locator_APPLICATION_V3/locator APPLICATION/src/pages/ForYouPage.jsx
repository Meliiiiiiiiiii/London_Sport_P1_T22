import { useState, useEffect, useMemo } from "react";
import * as Icons from "lucide-react";
import { Sparkles, Heart, ChevronRight, TrendingUp } from "lucide-react";
import { PrimaryButton } from "../components/Buttons";
import Footer from "../components/Footer";
import { fetchActivities } from "../api";
import { DATA } from "../data";
import { haversine } from "../utils";
import { FONT_DISPLAY, FONT_BODY, FONT_MONO, CAT_DOT_COLOR, CAT_ICON, useTheme } from "../theme";

function CatBadge({ type }) {
  const IconComp = Icons[CAT_ICON[type]] || Icons.Sparkles;
  const color = CAT_DOT_COLOR[type] || "#7A93A8";
  return (
    <div style={{ width: 36, height: 36, borderRadius: 12, flexShrink: 0, background: `${color}22`, display: "flex", alignItems: "center", justifyContent: "center" }}>
      <IconComp size={17} color={color} />
    </div>
  );
}

/*
 * Content-based recommendation scoring - not a trained statistical model,
 * but a genuine, explainable recommender-systems technique: build a
 * preference profile from what the user has favorited/viewed, then score
 * candidate activities by how well they match that profile.
 *
 * We deliberately don't attempt collaborative filtering (recommending
 * based on what similar USERS liked) - with only in-session favorites/
 * history and no real cross-user interaction data at scale, that would
 * have nothing genuine to learn from. Content-based, using the person's
 * own signal, is the honest fit for the data actually available here.
 */
function buildPreferenceProfile(likedActivities) {
  const typeCounts = {};
  const boroughCounts = {};
  let freeCount = 0;

  likedActivities.forEach((a) => {
    typeCounts[a.type] = (typeCounts[a.type] || 0) + 1;
    if (a.borough) boroughCounts[a.borough] = (boroughCounts[a.borough] || 0) + 1;
    if (a.free) freeCount += 1;
  });

  return {
    typeCounts,
    boroughCounts,
    prefersFree: likedActivities.length > 0 && freeCount / likedActivities.length >= 0.5,
    topTypes: Object.entries(typeCounts).sort((a, b) => b[1] - a[1]).map(([t]) => t),
  };
}

function scoreActivity(activity, profile) {
  let score = 0;
  if (profile.typeCounts[activity.type]) score += profile.typeCounts[activity.type] * 3;
  if (activity.borough && profile.boroughCounts[activity.borough]) score += profile.boroughCounts[activity.borough] * 2;
  if (activity.free === profile.prefersFree) score += 1;
  return score;
}

export default function ForYouPage({ goTo, user, favorites, history, activityCache, toggleFavorite, onOpenDetail, userLoc }) {
  const { C } = useTheme();
  const [pool, setPool] = useState([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState(null);

  const likedIds = useMemo(
    () => [...new Set([...favorites, ...history.map((h) => h.id)])],
    [favorites, history]
  );
  const likedActivities = useMemo(
    () => likedIds.map((id) => activityCache[id] || DATA.find((d) => d.id === id)).filter(Boolean),
    [likedIds, activityCache]
  );
  const profile = useMemo(() => buildPreferenceProfile(likedActivities), [likedActivities]);

  useEffect(() => {
    if (!user || profile.topTypes.length === 0) { setLoading(false); return; }
    let cancelled = false;
    setLoading(true);
    setLoadError(null);

    // pull candidates across the user's top 3 preferred categories
    Promise.all(profile.topTypes.slice(0, 3).map((type) => fetchActivities({ category: type })))
      .then((results) => {
        if (cancelled) return;
        const merged = results.flat();
        const seen = new Set();
        const deduped = merged.filter((a) => {
          if (seen.has(a.id) || likedIds.includes(a.id)) return false;
          seen.add(a.id);
          return true;
        });
        setPool(deduped);
      })
      .catch(() => !cancelled && setLoadError("Couldn't load recommendations right now."))
      .finally(() => !cancelled && setLoading(false));

    return () => { cancelled = true; };
  }, [user, profile.topTypes.join("|"), likedIds.join("|")]);

  const recommendations = useMemo(() => {
    return pool
      .map((a) => ({
        ...a,
        score: scoreActivity(a, profile),
        distance: userLoc ? haversine(userLoc.lat, userLoc.lng, a.lat, a.lng) : null,
      }))
      .sort((a, b) => b.score - a.score || (a.distance ?? 0) - (b.distance ?? 0))
      .slice(0, 12);
  }, [pool, profile, userLoc]);

  return (
    <div className="page-with-mobile-nav" style={{ background: C.bg, minHeight: 640, fontFamily: FONT_BODY }}>
      <div style={{ maxWidth: 720, margin: "0 auto", padding: "30px 24px" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 9, marginBottom: 6 }}>
          <Sparkles size={20} color={C.green} />
          <h1 style={{ fontFamily: FONT_DISPLAY, fontSize: 26, fontWeight: 800, color: C.textPrimary, margin: 0 }}>
            For you
          </h1>
        </div>
        <p style={{ fontFamily: FONT_BODY, fontSize: 13.5, color: C.textSecondary, margin: "0 0 22px" }}>
          Based on what you've favorited and viewed.
        </p>

        {!user ? (
          <EmptyState
            icon={Sparkles}
            title="Sign in for personalized picks"
            body="Create a free account so we can tailor recommendations to what you like."
            actionLabel="Sign in"
            onAction={() => goTo("signin")}
            C={C}
          />
        ) : likedActivities.length === 0 ? (
          <EmptyState
            icon={Heart}
            title="Favorite a few activities first"
            body="Tap the heart on activities you like, and we'll start suggesting similar ones here."
            actionLabel="Find activities"
            onAction={() => goTo("main")}
            C={C}
          />
        ) : loading ? (
          <div style={{ textAlign: "center", padding: "50px 20px", color: C.textMuted, fontFamily: FONT_BODY, fontSize: 13.5 }}>
            Finding activities you might like…
          </div>
        ) : loadError ? (
          <EmptyState icon={Sparkles} title="Something went wrong" body={loadError} C={C} />
        ) : recommendations.length === 0 ? (
          <EmptyState
            icon={Sparkles}
            title="Nothing new to suggest yet"
            body="Favorite a wider variety of activities and check back."
            C={C}
          />
        ) : (
          <>
            <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 14 }}>
              <TrendingUp size={13} color={C.textMuted} />
              <span style={{ fontFamily: FONT_MONO, fontSize: 11, color: C.textMuted, textTransform: "uppercase", letterSpacing: "0.05em" }}>
                Matched to your top picks: {profile.topTypes.slice(0, 3).join(" · ")}
              </span>
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
              {recommendations.map((a) => (
                <div
                  key={a.id}
                  onClick={() => onOpenDetail(a)}
                  style={{ background: C.surface, borderRadius: 16, padding: "14px 16px", cursor: "pointer", border: `1px solid ${C.border}`, display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12 }}
                >
                  <div style={{ display: "flex", alignItems: "center", gap: 13, minWidth: 0 }}>
                    <CatBadge type={a.type} />
                    <div style={{ minWidth: 0 }}>
                      <div style={{ fontFamily: FONT_BODY, fontSize: 14.5, fontWeight: 700, color: C.textPrimary, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                        {a.name}
                      </div>
                      <div style={{ fontFamily: FONT_BODY, fontSize: 12.5, color: C.textSecondary, marginTop: 2 }}>
                        {a.type} · {a.borough}{a.distance !== null ? ` · ${a.distance.toFixed(1)} mi` : ""}
                      </div>
                    </div>
                  </div>
                  <div style={{ display: "flex", alignItems: "center", gap: 12, flexShrink: 0 }}>
                    <span style={{ fontFamily: FONT_MONO, fontSize: 12.5, fontWeight: 700, padding: "4px 10px", borderRadius: 999, background: a.free ? C.goldSoft : C.surfaceAlt, color: a.free ? C.gold : C.textPrimary }}>
                      {a.free ? "FREE" : `£${a.price.toFixed(2)}`}
                    </span>
                    <button onClick={(e) => { e.stopPropagation(); toggleFavorite(a); }} style={{ background: "none", border: "none", cursor: "pointer", padding: 4 }}>
                      <Heart size={17} color={favorites.includes(a.id) ? C.green : C.textMuted} fill={favorites.includes(a.id) ? C.green : "none"} />
                    </button>
                    <ChevronRight size={16} color={C.textMuted} />
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
      </div>
      <Footer />
    </div>
  );
}

function EmptyState({ icon: Icon, title, body, actionLabel, onAction, C }) {
  return (
    <div style={{ textAlign: "center", padding: "50px 20px", background: C.surface, borderRadius: 18, border: `1px dashed ${C.border}` }}>
      <Icon size={26} color={C.green} style={{ marginBottom: 12 }} />
      <p style={{ fontFamily: FONT_BODY, fontSize: 15, fontWeight: 700, color: C.textPrimary, margin: "0 0 6px" }}>{title}</p>
      <p style={{ fontFamily: FONT_BODY, fontSize: 13.5, color: C.textSecondary, margin: "0 0 18px" }}>{body}</p>
      {actionLabel && <PrimaryButton onClick={onAction}>{actionLabel}</PrimaryButton>}
    </div>
  );
}
