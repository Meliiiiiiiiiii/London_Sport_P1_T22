export function haversine(lat1, lng1, lat2, lng2) {
  const R = 3958.8; // miles
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLng = ((lng2 - lng1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

export function timeSlotOf(timeStr) {
  if (!timeStr) return null;
  const hour = parseInt(timeStr.split(":")[0], 10);
  if (isNaN(hour)) return null;
  if (hour < 12) return "Morning";
  if (hour < 17) return "Afternoon";
  return "Evening";
}

export function isValidEmail(email) {
  // standard, practical email format check (not fully RFC-exhaustive, which is intentional -
  // overly strict regexes reject real addresses more often than they catch bad ones)
  return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email);
}

const DAY_NAMES = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

/*
 * Predicts the next N upcoming dates for an activity, based on its
 * recurring days_of_week + start_time. This is deterministic scheduling
 * math, not a statistical model - we're not predicting whether a session
 * will run, only calculating when the next occurrences of an already-known
 * weekly pattern fall, given today's date.
 *
 * Returns [] (not a guess) when there's no day-of-week data to work from -
 * e.g. many Our Parks sessions only carry a start_time, not a recurring
 * day pattern. Fabricating a date range in that case would misrepresent
 * data we don't actually have.
 */
export function getNextOccurrences(activity, count = 3, from = new Date()) {
  if (!activity?.days) return [];
  const dayNames = activity.days.split(",").map((d) => d.trim()).filter(Boolean);
  const dayIndexes = dayNames
    .map((name) => DAY_NAMES.findIndex((d) => d.toLowerCase() === name.toLowerCase()))
    .filter((i) => i >= 0);
  if (dayIndexes.length === 0) return [];

  let [hh, mm] = [9, 0];
  if (activity.time && /^\d{1,2}:\d{2}$/.test(activity.time)) {
    const parts = activity.time.split(":").map(Number);
    hh = parts[0];
    mm = parts[1];
  }

  const occurrences = [];
  const cursor = new Date(from);
  cursor.setHours(0, 0, 0, 0);

  // walk forward day by day until we've collected `count` matching occurrences
  // (bounded search - at most ~5 weeks out, since dayIndexes is never empty here)
  for (let i = 0; i < 40 && occurrences.length < count; i++) {
    const candidate = new Date(cursor);
    candidate.setDate(cursor.getDate() + i);
    if (dayIndexes.includes(candidate.getDay())) {
      const withTime = new Date(candidate);
      withTime.setHours(hh, mm, 0, 0);
      if (withTime > from) {
        occurrences.push(withTime);
      }
    }
  }
  return occurrences;
}

export function formatOccurrence(date) {
  return date.toLocaleDateString("en-GB", { weekday: "short", day: "numeric", month: "short" }) +
    ", " + date.toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" });
}
