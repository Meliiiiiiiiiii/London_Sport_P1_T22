/* ---------- Gradient-driven design system (dark + light) ---------- */
const DARK = {
  bg: "#070B10",
  surface: "#111922",
  surfaceAlt: "#161F2A",
  surfaceHover: "#1B2530",
  border: "rgba(255,255,255,0.08)",
  borderStrong: "rgba(255,255,255,0.16)",

  blue: "#2E7BB0",
  blueSoft: "rgba(46,123,176,0.16)",
  green: "#22A06B",
  greenSoft: "rgba(34,160,107,0.16)",
  gold: "#F4B740",
  goldSoft: "rgba(244,183,64,0.16)",
  danger: "#FF6B5B",

  textPrimary: "#F5F7FA",
  textSecondary: "rgba(245,247,250,0.64)",
  textMuted: "rgba(245,247,250,0.40)",
  white: "#FFFFFF",

  navBg: "rgba(7,11,16,0.85)",
  shadowStrong: "0 30px 80px rgba(0,0,0,0.5)",
  colorScheme: "dark",
};

const LIGHT = {
  bg: "#F5F7FA",
  surface: "#FFFFFF",
  surfaceAlt: "#EEF2F6",
  surfaceHover: "#E4E9EF",
  border: "rgba(10,20,30,0.10)",
  borderStrong: "rgba(10,20,30,0.20)",

  blue: "#2166A0",
  blueSoft: "rgba(33,102,160,0.12)",
  green: "#1B8A5A",
  greenSoft: "rgba(27,138,90,0.12)",
  gold: "#B8811F",
  goldSoft: "rgba(184,129,31,0.14)",
  danger: "#D8433A",

  textPrimary: "#0F1720",
  textSecondary: "rgba(15,23,32,0.66)",
  textMuted: "rgba(15,23,32,0.44)",
  white: "#FFFFFF",

  navBg: "rgba(255,255,255,0.85)",
  shadowStrong: "0 30px 80px rgba(15,23,32,0.14)",
  colorScheme: "light",
};

export const PALETTES = { dark: DARK, light: LIGHT };

const THEME_STORAGE_KEY = "ml_theme";

function loadStoredMode() {
  try {
    const stored = localStorage.getItem(THEME_STORAGE_KEY);
    return stored === "light" || stored === "dark" ? stored : "dark";
  } catch {
    return "dark";
  }
}

export let themeMode = loadStoredMode();

// `C` is a stable object reference that every component reads from at
// render time. We mutate its contents in place (rather than creating a
// new object) so every file that imported `{ C }` automatically sees
// updated values as soon as the app re-renders after a theme change.
export const C = { ...PALETTES[themeMode] };

function applyDomTheme(mode) {
  if (typeof document === "undefined") return;
  document.documentElement.classList.toggle("light", mode === "light");
  document.documentElement.style.colorScheme = mode === "light" ? "light" : "dark";
}

applyDomTheme(themeMode);

export function setThemeMode(mode) {
  if (mode !== "dark" && mode !== "light") return;
  themeMode = mode;
  Object.assign(C, PALETTES[mode]);
  try { localStorage.setItem(THEME_STORAGE_KEY, mode); } catch {}
  applyDomTheme(mode);
}

export const GRADIENT = "linear-gradient(135deg, #2E7BB0 0%, #22A06B 100%)";
export const GRADIENT_SOFT = "linear-gradient(135deg, rgba(46,123,176,0.14) 0%, rgba(34,160,107,0.14) 100%)";
export const GLOW = "0 8px 30px rgba(34,160,107,0.25), 0 4px 14px rgba(46,123,176,0.18)";

export const FONT_DISPLAY = "'Bricolage Grotesque', 'Space Grotesk', sans-serif";
export const FONT_BODY = "'Public Sans', 'Inter', sans-serif";
export const FONT_MONO = "'IBM Plex Mono', monospace";

// cycling palette for category accents (no orange, per brand rule)
const CAT_PALETTE = [C.blue, C.green, C.gold, "#7A93A8"];
const CAT_ORDER = [
  "Swimming", "Gym / Fitness", "Yoga, Pilates & Studio", "Group Exercise", "Dance",
  "Racquet Sports", "Team Sports", "Martial Arts", "Bootcamp & Outdoor Fitness",
  "Walking / Running", "Cycling", "Personal Training", "Other / Unspecified",
  "Wellness & Facility Access",
];
export const CAT_DOT_COLOR = Object.fromEntries(
  CAT_ORDER.map((name, i) => [name, CAT_PALETTE[i % CAT_PALETTE.length]])
);

export const CAT_ICON = {
  "Swimming": "Waves",
  "Gym / Fitness": "Dumbbell",
  "Yoga, Pilates & Studio": "Flower2",
  "Group Exercise": "Users",
  "Dance": "Music2",
  "Racquet Sports": "CircleDot",
  "Team Sports": "Trophy",
  "Martial Arts": "Swords",
  "Bootcamp & Outdoor Fitness": "Flame",
  "Walking / Running": "Footprints",
  "Cycling": "Bike",
  "Personal Training": "UserCheck",
  "Other / Unspecified": "Sparkles",
  "Wellness & Facility Access": "HeartPulse",
};

// London bounding box, for projecting lat/lng into the schematic SVG map
export const BOUNDS = { latMin: 51.30, latMax: 51.70, lngMin: -0.52, lngMax: 0.32 };

export function project(lat, lng, w, h) {
  const x = ((lng - BOUNDS.lngMin) / (BOUNDS.lngMax - BOUNDS.lngMin)) * w;
  const y = h - ((lat - BOUNDS.latMin) / (BOUNDS.latMax - BOUNDS.latMin)) * h;
  return { x, y };
}

export function clampCoord(v, min, max) {
  return Math.max(min, Math.min(max, v));
}
