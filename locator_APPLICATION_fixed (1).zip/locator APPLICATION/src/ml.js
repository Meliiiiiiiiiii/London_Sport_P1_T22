/*
 * A small, genuinely-trained logistic regression classifier for the
 * "For You" recommendations, replacing the earlier hand-picked scoring
 * weights (x3 / x2 / x1) with weights actually learned via gradient
 * descent from the user's own interaction data.
 *
 * Labels:
 *   - favorited activity  -> positive example (y = 1)
 *   - viewed in history but NOT favorited -> implicit negative (y = 0)
 *     (a standard real-world technique: absence of a positive action,
 *     after genuine exposure, is treated as weak negative signal)
 *
 * This is intentionally simple - plain batch gradient descent with L2
 * regularisation, no external ML library - because the training set is
 * tiny (a handful of interactions per user) and a from-scratch model
 * keeps every step inspectable and explainable, which matters more than
 * raw sophistication at this data scale.
 */

const sigmoid = (z) => 1 / (1 + Math.exp(-z));
const dot = (a, b) => a.reduce((sum, v, i) => sum + v * b[i], 0);

// Build a fixed feature vocabulary (one-hot category + one-hot borough + free flag)
// from whatever set of activities is currently in play, so encode() below always
// produces vectors of a consistent length for both training and prediction.
export function buildVocab(activities) {
  const types = [...new Set(activities.map((a) => a.type).filter(Boolean))].sort();
  const boroughs = [...new Set(activities.map((a) => a.borough).filter(Boolean))].sort();
  return { types, boroughs };
}

export function encode(activity, vocab) {
  const typeVec = vocab.types.map((t) => (activity.type === t ? 1 : 0));
  const boroughVec = vocab.boroughs.map((b) => (activity.borough === b ? 1 : 0));
  return [...typeVec, ...boroughVec, activity.free ? 1 : 0];
}

export function trainLogisticRegression(X, y, { epochs = 300, lr = 0.5, l2 = 0.05 } = {}) {
  const n = X.length;
  const d = X[0].length;
  let weights = new Array(d).fill(0);
  let bias = 0;

  for (let epoch = 0; epoch < epochs; epoch++) {
    const gradW = new Array(d).fill(0);
    let gradB = 0;

    for (let i = 0; i < n; i++) {
      const pred = sigmoid(dot(X[i], weights) + bias);
      const error = pred - y[i];
      for (let j = 0; j < d; j++) gradW[j] += error * X[i][j];
      gradB += error;
    }

    // L2-regularised gradient step - keeps weights small and stable given
    // how few training examples exist (avoids wild overfitting to 3-4 points)
    for (let j = 0; j < d; j++) {
      weights[j] -= lr * (gradW[j] / n + l2 * weights[j]);
    }
    bias -= lr * (gradB / n);
  }

  return { weights, bias };
}

export function predictProbability(model, activity, vocab) {
  const x = encode(activity, vocab);
  return sigmoid(dot(x, model.weights) + model.bias);
}

// Minimum data needed before we trust a trained model over the simple
// rule-based fallback - an underdetermined model on 1-2 points is not
// meaningfully better than a coin flip, so we're explicit about the floor
// rather than pretending a model trained on almost nothing is reliable.
export const MIN_POSITIVE_EXAMPLES = 2;
export const MIN_NEGATIVE_EXAMPLES = 1;
